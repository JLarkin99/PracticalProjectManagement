﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PPM_Maze
{
    class Level
    {
        /*Implement:
         * Path
         * List of obstacles
         * List of treasure (to be implemented later)
         * Finish line location
         * Level width(same as path width)
         */
        Path path;


       


        public Level()
        {
            

        }


    }
}
