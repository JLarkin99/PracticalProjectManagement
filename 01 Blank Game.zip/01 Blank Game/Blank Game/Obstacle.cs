﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PPM_Maze
{
    class Obstacle
    {
        /*
         * To implement:
         * Vector2 position
         * width + height
         * shape?
         * Function to check for collision
         * draw obstacle good colour/ bad colour depending on collision
         */
        Vector2 position;
        Vector2 widthHeight;
        

        public Obstacle(int posX, int posY, int w, int h)
        {
            position.X = posX;
            position.Y = posY;
            widthHeight.X = w;
            widthHeight.Y = h;

        }

        public Boolean isPlayerInBounds(Vector2 location)
        {
            if ((location.X > position.X && location.X < position.X + widthHeight.X) && 
                (location.Y > position.Y && location.Y < position.Y + widthHeight.Y))
            {
                return true;
            }
            else { return false; }
        }

        public void Draw(SpriteBatch spritebatch,Texture2D whiteRect, Color color)
        {
            spritebatch.Begin(SpriteSortMode.Deferred, null, SamplerState.LinearWrap);
            spritebatch.Draw(whiteRect, position, new Rectangle((int)position.X, (int)position.Y, (int)widthHeight.X, (int)widthHeight.Y), color);
            spritebatch.End();
        }
    }
}
