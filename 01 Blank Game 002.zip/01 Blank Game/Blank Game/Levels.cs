﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace PPM_Maze
{
    public class Levels
    {
        /*Implement:
         * Path
         * List of obstacles
         * List of treasure (to be implemented later)
         * Finish line location
         * Level width(same as path width)
         */
        public static Path path { get; set; }
        //protected Obstacle[] obstacleList;
        public List<Obstacle> obstacleList { get; set; }
        protected int levelWidth;
        protected Texture2D pathTexture;
        



        public Levels()
        {
            
            
        }

        public void  Draw (SpriteBatch spritebatch, Texture2D whiteRect)
        {
            path.Draw(spritebatch);
            try
            {
                for (int i = 0; i < obstacleList.Count(); i++)
                {
                    obstacleList[i].Draw(spritebatch, whiteRect);
                }
            }
            catch { }
        }

        

    }
    public class LevelOne : Levels
    {
        public LevelOne(int levelwidth, Texture2D pathtexture )
        {
            levelWidth = levelwidth;
            pathTexture = pathtexture;
            List<Obstacle> obstacleList = new List<Obstacle>();
            initialisePath();
            initialiseObstacles();

        }

        public void initialisePath()
        {
            path = new Path(levelWidth, Game1.windowHeight /4, pathTexture);
        }
        public void initialiseObstacles()
        {

            obstacleList = new List<Obstacle>
            { new Obstacle(1000, 200, 80, 80),
             new Obstacle(300, 100, 50, 100)
            };

            obstacleList.Add(new Obstacle(1000, 200, 80, 80));
            obstacleList.Add(new Obstacle(300, 100, 50, 50));
            //return tempObstacleArray;
        }
       
    }
}
