﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace PPM_Maze
{
    public class Obstacle
    {
        /*
         * To implement:
         * Vector2 position
         * width + height
         * shape?
         * Function to check for collision
         * draw obstacle good colour/ bad colour depending on collision
         */
        Vector2 position;
        Vector2 widthHeight;
        Camera2D _camera = Game1._camera;
        int cameraScrollSpeed = Game1.cameraScrollSpeed;
        

        public Obstacle(int posX, int posY, int w, int h)
        {
            position.X = posX;
            position.Y = posY;
            widthHeight.X = w;
            widthHeight.Y = h;

        }

        public Boolean isPlayerInBounds(Vector2 location)
        {
            if ((location.X > position.X && location.X < position.X + widthHeight.X) && 
                (location.Y > position.Y && location.Y < position.Y + widthHeight.Y))
            {
                return true;
            }
            else { return false; }
        }

        public void updatePosition(GameTime gameTime)
        {
            var deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;
            position.X -= cameraScrollSpeed*deltaTime;
        }

        public void Draw(SpriteBatch spritebatch,Texture2D whiteRect)
        {
            var viewMatrix = _camera.GetViewMatrix();
            spritebatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.LinearWrap, DepthStencilState.Default, RasterizerState.CullNone, null, _camera.GetViewMatrix());
            if (isPlayerInBounds(Game1.cursor.Location))
            {
                spritebatch.Draw(whiteRect, position, new Rectangle((int)position.X, (int)position.Y, (int)widthHeight.X, (int)widthHeight.Y), Game1.goodColor);
            }
            else
            {
                spritebatch.Draw(whiteRect, position, new Rectangle((int)position.X, (int)position.Y, (int)widthHeight.X, (int)widthHeight.Y), Game1.badColor);
            }
            spritebatch.End();
        }
    }
}
